from flask import *  
app = Flask(__name__)  
  
@app.route('/login',methods = ['POST'])  
def login():  
        name=request.form['name']  
        college=request.form['college']
        return "Hello, Welcome Mr.{0} from {1}".format(name,college) 

if __name__ == '__main__':  
   app.run(debug = True) 

