from flask import *  
app = Flask(__name__)  
  
@app.route('/login',methods = ['POST'])  
def login():  
        name=request.form['name']  
        #name=request.args.get('name')  
        return "HELLO, WELCOME %s" %name  
   
if __name__ == '__main__':  
   app.run(debug = True)